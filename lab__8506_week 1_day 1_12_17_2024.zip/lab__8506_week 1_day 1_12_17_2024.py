#Problem 1 :
 #Write a program to take the diamater of a circle as user input
 #and calculate and print its area & circumference.

diameter = 10 
pi = 3.14
radius = diameter / 2
area = pi * (radius ** 2)
circumference = pi * diameter


print(f"Diameter= {diameter}")
print(f"Radius= {radius}")
print(f"Area= {area}")
print(f"Circumference= {circumference}")
