#Problem 2:
#Write a program to input the temperature in celcius
#and calculate ans print it in Farhenheit.

celsius = float(input("Enter the temperature in Celsius: "))
fahrenheit = (celsius * 9/5) + 32
print(f"The temperature in Fahrenheit is: {fahrenheit:.2f}")
